import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';


import { HomeComponent } from '../../src/app/component/home/home.component';
import { SignupComponent } from '../../src/app/component/signup/signup.component';
import { LoginComponent } from '../../src/app/component/login/login.component';
import { AccountComponent } from '../../src/app/component/account/account.component';
import { CartComponent } from '../../src/app/component/cart/cart.component';
import { WhishlistComponent } from './component/wishlist/whishlist.component';
import { ProductDetailsComponent } from '../app/component/product-details/product-details.component';
import { CategoryComponent } from '../app/component/category/category.component';
import { NotFoundComponent } from '../app/component/not-found/not-found.component';
import { Register } from './interfaces/register';
import { RegistorComponent } from './component/registor/registor.component';


const routes: Routes = [
  { path: '', redirectTo: '/home', pathMatch: 'full' },
  { path: 'home', component: HomeComponent },
  { path: 'signup', component: SignupComponent },
  { path: 'login', component: LoginComponent },
  { path: 'account', component: AccountComponent },
  { path: 'cart', component: CartComponent },
  { path: 'wishlist', component: WhishlistComponent },
  { path: 'product/:id', component: ProductDetailsComponent },
  { path: 'category/:id', component: CategoryComponent },
  { path: '**', component: NotFoundComponent },
  {path: 'register', component: RegistorComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { scrollPositionRestoration: 'enabled' })], 
  exports: [RouterModule]
})
export class AppRoutingModule { }
