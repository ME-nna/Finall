import { Component } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import { FormGroup, Validators } from '@angular/forms';
import { Register } from '../../interfaces/register';
import { AuthService } from '../../services/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-registor',
  templateUrl: './registor.component.html',
  styleUrl: './registor.component.css'
})
export class RegistorComponent {
  registerForm: FormGroup;

  constructor(private fb: FormBuilder, private authService: AuthService ,  private router: Router) {
    this.registerForm = this.fb.group({
      userName: ['', Validators.required],
      userEmail: ['', [Validators.required, Validators.email]],
      userPassword: ['', [Validators.required, Validators.minLength(6)]]
    });
  }

  onSubmit() {
    if (this.registerForm.valid) {
      const user: Register = this.registerForm.value; // Type the form value
      this.authService.register(user).subscribe({
        next: (response: any) => {
          console.log('Registration successful', response);
          // Handle success (e.g., navigate to login page)
        },
        error: (error : any) => {
          console.error('Registration failed', error);
          // Handle error (e.g., display error message)
        }
      });
    }
  }
  model: { userEmail: string; userPassword: string; userName: string } = {
    userEmail: '',
    userPassword: '',
   userName: ''
  };
  
  register() {
    // 1. Input Validation
    if (!this.model.userEmail || !this.model.userPassword) {
      alert('Please fill in all required fields.');
      return;
    }

    // 2. Send Registration Data to the Backend
    this.authService.register(this.model).subscribe(
      response => {
        // 3. Handle Success Response
        console.log('Registration successful:', response);
        alert('Registration successful! You can now log in.');

        // Optionally redirect to login or home page
        this.router.navigate(['/login']); // Adjust to your routes
      },
      error => {
        // 4. Handle Error Response
        console.error('Registration failed:', error);
        alert('Registration failed. Please try again.');
      }
    );
  }
}
