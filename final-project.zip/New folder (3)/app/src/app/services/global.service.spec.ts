import { TestBed } from '@angular/core/testing';
import { GlobalService } from './global.service';

describe('GlobalService', () => {
  let service: GlobalService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [GlobalService] // Ensure the service is provided here
    });
    service = TestBed.inject(GlobalService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  // Example test case for a hypothetical method
  it('should have a method to get global data', () => {
    expect(service.getGlobalData).toBeDefined();
  });

 

  it('should set and get a value', () => {
    const key = 'testKey';
    const value = 'testValue';

    service.setValue(key, value); // Assuming a method setValue exists
    expect(service.getValue(key)).toEqual(value); // Assuming a method getValue exists
  });
});