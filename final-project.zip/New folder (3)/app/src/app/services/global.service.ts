import { Injectable } from '@angular/core';

/**
 * A service to manage global application state such as the app name and additional global data.
 */
@Injectable({
  providedIn: 'root',
})
export class GlobalService {
  private appName: string = 'My Angular App'; // Default app name
  private globalData: { [key: string]: any } = {}; // An object to store global data

  constructor() {}

  /**
   * Get the current application name.
   * @returns {string} The application name.
   */
  getAppName(): string {
    return this.appName;
  }

  /**
   * Set a new application name.
   * @param {string} name - The new application name.
   */
  setAppName(name: string): void {
    if (this.isValidAppName(name)) {
      this.appName = name;
    } else {
      console.error('Invalid app name');
    }
  }

  /**
   * Check if the provided name is a valid application name.
   * @param {string} name - The name to validate.
   * @returns {boolean} True if valid; otherwise, false.
   */
  private isValidAppName(name: string): boolean {
    return name.length > 0; // Example validation
  }

  /**
   * Reset the application name to the default value.
   */
  resetAppName(): void {
    this.appName = 'My Angular App';
  }

  /**
   * Get global data based on a key.
   * @param {string} key - The key for the global data.
   * @returns {any} The value associated with the key.
   */
  getGlobalData(key: string): any {
    return this.globalData[key];
  }

  /**
   * Set global data for a given key.
   * @param {string} key - The key for the global data.
   * @param {any} value - The value to be stored.
   */
  setGlobalData(key: string, value: any): void {
    this.globalData[key] = value;
  }
  setValue(key: string, value: any): void {
    this.globalData[key] = value;
  }
  getValue(key: string): any {
    return this.globalData[key];
  }
}
