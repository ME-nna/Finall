import { TestBed } from '@angular/core/testing';
import { AuthService } from './auth.service';

describe('AuthService', () => {
  let service: AuthService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [AuthService] // Ensure the service is provided here
    });
    service = TestBed.inject(AuthService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  // Example test cases - customize these based on your AuthService functionality
  it('should have a login method', () => {
    expect(service.login).toBeDefined();
  });

  it('should return a token on successful login', () => {
    const token = service.login('username', 'password'); // Example method
    expect(token).toBeTruthy(); // Adjust based on expected outcome
  });

  it('should have a logout method', () => {
    expect(service.logout).toBeDefined();
  });
});

