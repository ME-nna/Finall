import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';


export interface AuthResponse {
  token: string; // Adjust this based on your API response
}

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  private authUrl = 'https://api.example.com/auth'; // Consider moving this to an environment file

  constructor(private http: HttpClient) {}

  login(username: string, password: string): Observable<AuthResponse> {
    return this.http
      .post<AuthResponse>(`${this.authUrl}/login`, { username, password })
      .pipe(
        catchError(this.handleError) // Error handling for HTTP requests
      );
  }

  logout(): void {
    localStorage.removeItem('token');
  }

  isLoggedIn(): boolean {
    return !!localStorage.getItem('token');
  }

  private handleError(error: HttpErrorResponse) {
    // Handle the error as needed
    let errorMessage = 'An unknown error occurred!';
    if (error.error instanceof ErrorEvent) {
      // Client-side error
      errorMessage = `Error: ${error.error.message}`;
    } else {
      // Server-side error
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
    }
    return throwError(errorMessage); // Return an observable with a user-facing error message
  }
  register(userDetails: any): Observable<AuthResponse> {
    return this.http
      .post<AuthResponse>(`${this.authUrl}/register`, userDetails) // Sending user details to the backend
      .pipe(
        catchError(this.handleError) // Handle any errors using the existing handleError method
      );
  }
  
}
