import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AccountComponent } from './component/account/account.component';
import { CartComponent } from './component/cart/cart.component';
import { CategoryComponent } from './component/category/category.component';
import { HomeComponent } from './component/home/home.component';
import { LoginComponent } from './component/login/login.component';
import { NotFoundComponent } from './component/not-found/not-found.component';
import { ProductDetailsComponent } from './component/product-details/product-details.component';
import { RegistorComponent } from './component/registor/registor.component';
import { SignupComponent } from './component/signup/signup.component';
import { WhishlistComponent } from './component/wishlist/whishlist.component';
import { RouterModule } from '@angular/router'; 
import { CommonModule } from '@angular/common';




@NgModule({
  declarations: [
    AppComponent,
    AccountComponent,
    CartComponent,
    CategoryComponent,
    HomeComponent,
    LoginComponent,
    NotFoundComponent,
    ProductDetailsComponent,
    RegistorComponent,
    SignupComponent,
    WhishlistComponent,
    ReactiveFormsModule,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule.forRoot([]),
    RouterModule
  ],
  providers: [],
  bootstrap: [AppComponent],
  exports: [RegistorComponent]
})
export class AppModule { }
export class YourModule { }
