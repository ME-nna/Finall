export interface Register {
    userName : string
    userEmail : string
    userPassword : string
}

